function onCreate()
    makeLuaSprite('theVoid','oiiaBG',0,0)
    addLuaSprite('theVoid',false)
    scaleObject('theVoid', 150, 150)
end

function onCreatePost()
	
	setProperty('gf.visible',false)

end