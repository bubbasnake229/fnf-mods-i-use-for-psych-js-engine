function onCreatePost()
    if not botPlay then return end
    setProperty('botplayTxt.visible', false)
    function goodNoteHit(i, d, t, s)
        if s then return end
        addScore(350)
        setTextString('scoreTxt', 'Score: ' .. getScore() .. ' | Misses: 0 | Rating: Perfect!! (100%) - SFC')
        runHaxeCode([[
			if(game.scoreTxtTween != null)
				game.scoreTxtTween.cancel();
			game.scoreTxt.scale.x = 1.075;
			game.scoreTxt.scale.y = 1.075;
			game.scoreTxtTween = FlxTween.tween(game.scoreTxt.scale, {x: 1, y: 1}, 0.2, {
				onComplete: function(twn:FlxTween) {
					game.scoreTxtTween = null;
				}
			});
        ]])
    end
end