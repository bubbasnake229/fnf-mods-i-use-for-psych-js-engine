function onUpdatePost(elapsed) setProperty('botplayTxt.text', '   ') end
