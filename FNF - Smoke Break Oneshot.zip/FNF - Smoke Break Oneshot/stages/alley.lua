
--How makeLuaSprite works:
--makeLuaSprite(<SPRITE VARIABLE>, <SPRITE IMAGE FILE NAME>, <X>, <Y>);
--"Sprite Variable" is how you refer to the sprite you just spawned in other methods like "setScrollFactor" and "scaleObject" for example

--so for example, i made the sprites "stagelight_left" and "stagelight_right", i can use "scaleObject('stagelight_left', 1.1, 1.1)"
--to adjust the scale of specifically the one stage light on left instead of both of them

function onCreate()
	-- background shit
	makeLuaSprite('wall', 'backgrounds/alleyway/alleyWall', -210, -200);
	setScrollFactor('wall', 1, 1);
	scaleObject('wall', 1.25, 1.25);
	
	makeLuaSprite('floor', 'backgrounds/alleyway/alleyFloor', -210, -225);
	setScrollFactor('floor', 1, 1);
	scaleObject('floor', 1.25, 1.25);

	makeLuaSprite('lamp', 'backgrounds/alleyway/alleyLamp', -250, -145);
	setScrollFactor('lamp', 1, 1);
	scaleObject('lamp', 1.25, 1.25);

	makeLuaSprite('light', 'backgrounds/alleyway/alleyLight', -250, -145);
	setScrollFactor('light', 1, 1);
	scaleObject('light', 1.25, 1.25);

	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
		makeLuaSprite('dumpster', 'backgrounds/alleyway/alleyDump', -325, -280);
		setScrollFactor('dumpster', 0.9, 0.9);
		scaleObject('dumpster', 1.25, 1.25);

		makeLuaSprite('trash', 'backgrounds/alleyway/alleyTrash', -100, -360);
		setScrollFactor('trash', 0.9, 0.9);
		scaleObject('trash', 1.25, 1.25);
	end

	addLuaSprite('wall', false);
	addLuaSprite('lamp', false);
	addLuaSprite('floor', false);
	addLuaSprite('light', true);
	addLuaSprite('dumpster', true);
	addLuaSprite('trash', true);
end