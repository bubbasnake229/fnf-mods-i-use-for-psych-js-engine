function onCreate()

	makeLuaSprite('theBg','farmland',-280,-130)
	addLuaSprite('theBg',false)
	setLuaSpriteScrollFactor('theBg', 0.9, 0.9)

end

function onBeatHit(   )-- for every beat
	
end

function onStepHit(   )-- for every step
	-- body
end

function onUpdate(   )
	-- body
end
